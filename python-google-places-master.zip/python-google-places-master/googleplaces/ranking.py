"""
Valid place search rankings to be optionally used in Google Place query
api calls.

@author: sam@slimkrazy.com
"""

DISTANCE = 'distance'
PROMINENCE = 'prominence'
